export const baseUrl = process.env.NODE_ENV === 'production' ? 'http://' + window.location.hostname + ':8067' : '/apis';
