interface H3Utils {
  // 此接口为示例，应从node_modules中导入
}

interface Window{
  $utils: H3Utils;
}
