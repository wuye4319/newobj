import toolbar from './toolbar.vue';

export default toolbar;
