import table from './table.vue';

export default table;
