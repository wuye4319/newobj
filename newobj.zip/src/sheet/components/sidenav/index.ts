import sidenav from './sidenav.vue';

export default sidenav;
