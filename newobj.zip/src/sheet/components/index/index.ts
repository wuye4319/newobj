import index from './index.vue';

export default index;
