export default [{
  path: '/index',
  name: 'index',
  meta: {
    title: '工作表'
  },
  component: () => import('@/sheet/pages/index.vue')
}];
