export enum DemoAction {
  Example = 'example'
}

export enum DemoMutation {
  Example = 'testfoo'
}
