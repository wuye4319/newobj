import { GlobalState } from '@/wrapper/store';
import { ActionTree } from 'vuex';
import { DemoState } from './index';
import { DemoAction } from './types';

const actions: ActionTree<DemoState, GlobalState> = {

};

export default actions;
