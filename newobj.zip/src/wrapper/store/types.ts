export enum GlobalMutation {
  Example = 'foo',
  data = 'data',
  buffer = 'buffer'
}
