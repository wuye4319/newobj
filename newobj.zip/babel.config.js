module.exports = {
  presets: [
    '@vue/app',
  ],
  plugins: [
    ['import', { libraryName: 'h3-antd-vue', libraryDirectory: 'es', style: true }]
  ]
};
